from fastapi import FastAPI
from pydantic import BaseModel
import yfinance as yf
import requests

app = FastAPI()

NEWS_API_KEY = "your_news_api_key"  # Optional, add your API key here

class StockRequest(BaseModel):
    symbol: str

@app.post("/stock")
def get_stock_price(req: StockRequest):
    data = yf.Ticker(req.symbol).history(period="1d", interval="5m")
    return {"symbol": req.symbol, "latest": data.tail(1).to_dict()}

@app.get("/news/{keyword}")
def get_financial_news(keyword: str):
    url = f"https://newsapi.org/v2/everything?q={keyword}&apiKey={NEWS_API_KEY}"
    response = requests.get(url)
    return response.json()
