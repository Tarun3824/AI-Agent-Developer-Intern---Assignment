from fastapi import FastAPI
from pydantic import BaseModel
from langchain_openai import ChatOpenAI
import os

# 👇 Set the API key directly here
os.environ["OPENAI_API_KEY"] = "your-api-key-here"

app = FastAPI()
llm = ChatOpenAI(temperature=0.7)

class PromptInput(BaseModel):
    query: str

@app.post("/generate")
def generate_brief(p: PromptInput):
    prompt_template = """
    You are a financial analyst AI assistant. Generate a clear, concise market summary based on the input query.

    Input: {query}

    Market Brief:
    """
    from langchain.prompts import PromptTemplate
    from langchain.chains import LLMChain

    prompt = PromptTemplate(template=prompt_template, input_variables=["query"])
    chain = LLMChain(llm=llm, prompt=prompt)
    result = chain.run(query=p.query)
    return {"market_brief": result}
