from fastapi import FastAPI, UploadFile, File
from pydantic import BaseModel
from TTS.api import TTS
import whisper
import time
from logger_util import setup_logger

app = FastAPI()
logger = setup_logger("voice_agent", "logs/voice_agent.log")

tts_model = TTS(model_name="tts_models/en/ljspeech/tacotron2-DDC", progress_bar=False)
asr_model = whisper.load_model("base")

class TTSRequest(BaseModel):
    text: str

@app.post("/speak")
def speak_text(data: TTSRequest):
    start_time = time.time()
    logger.info(f"Received TTS request with text length: {len(data.text)}")

    file_path = "outputs/output.wav"
    try:
        tts_model.tts_to_file(text=data.text, file_path=file_path)
        inference_time = time.time() - start_time
        logger.info(f"TTS inference completed in {inference_time:.2f}s")
        return {"message": "Audio generated", "file": file_path}
    except Exception as e:
        logger.error(f"TTS error: {str(e)}")
        return {"error": str(e)}

@app.post("/transcribe")
async def transcribe_audio(file: UploadFile = File(...)):
    start_time = time.time()
    logger.info(f"Received STT request for file: {file.filename}")

    input_path = f"outputs/{file.filename}"
    try:
        with open(input_path, "wb") as f:
            f.write(await file.read())
        result = asr_model.transcribe(input_path)
        inference_time = time.time() - start_time
        logger.info(f"STT inference completed in {inference_time:.2f}s, text length: {len(result['text'])}")
        return {"text": result["text"]}
    except Exception as e:
        logger.error(f"STT error: {str(e)}")
        return {"error": str(e)}
