import os
from TTS.utils.manage import ModelManager

# Force new cache location
os.environ["TTS_CACHE_PATH"] = "C:/Users/tarun/tts_cache"

model_name = "tts_models/en/ljspeech/tacotron2-DDC"
manager = ModelManager()
manager.download_model(model_name)
