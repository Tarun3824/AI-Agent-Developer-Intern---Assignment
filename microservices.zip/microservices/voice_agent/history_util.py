import json
import os
import time

HISTORY_FILE = "logs/query_history.json"

def save_query_history(logger, query_type, query_text, response_text, success=True):
    try:
        if os.path.exists(HISTORY_FILE):
            with open(HISTORY_FILE, "r") as f:
                history = json.load(f)
        else:
            history = []

        entry = {
            "type": query_type,
            "query": query_text,
            "response": response_text,
            "success": success,
            "timestamp": time.time()
        }
        history.append(entry)

        with open(HISTORY_FILE, "w") as f:
            json.dump(history, f, indent=2)
    except Exception as e:
        logger.error(f"Error saving query history: {str(e)}")
