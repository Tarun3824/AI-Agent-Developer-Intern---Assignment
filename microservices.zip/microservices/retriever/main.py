from fastapi import FastAPI
from pydantic import BaseModel
from langchain.vectorstores import FAISS
from langchain_openai import OpenAIEmbeddings  # UPDATED import

import os

app = FastAPI()

# Option 1: Set API key directly in code (NOT recommended for production)
# embeddings = OpenAIEmbeddings(openai_api_key="your-openai-api-key")

# Option 2: Use environment variable (recommended)
# Make sure you've set: export OPENAI_API_KEY=your-openai-api-key
embeddings = OpenAIEmbeddings()  # Will read from environment

VECTOR_DIR = "vector_store/"

class Query(BaseModel):
    question: str

@app.post("/retrieve")
def retrieve_relevant_docs(q: Query):
    # Load vector store and perform similarity search
    vs = FAISS.load_local(VECTOR_DIR, embeddings)
    results = vs.similarity_search(q.question, k=3)
    return {"results": [doc.page_content for doc in results]}
