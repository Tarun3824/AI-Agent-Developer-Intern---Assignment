import streamlit as st
import requests
import os

VOICE_AGENT_URL = "http://localhost:8005"

st.title("🎙️ Voice Agent Interface")

# -- Text-to-Speech --
st.header("Text to Speech")
text_input = st.text_area("Enter text to speak:")

if st.button("Convert to Speech"):
    if not text_input.strip():
        st.warning("Please enter some text!")
    else:
        response = requests.post(
            f"{VOICE_AGENT_URL}/speak",
            json={"text": text_input}
        )
        if response.status_code == 200:
            audio_file_path = response.json()["file"]
            audio_bytes = open(audio_file_path, "rb").read()
            st.audio(audio_bytes, format="audio/wav")
        else:
            st.error("Error generating speech.")

# -- Speech-to-Text --
st.header("Speech to Text")

uploaded_file = st.file_uploader("Upload a WAV audio file", type=["wav"])

if uploaded_file is not None:
    if st.button("Transcribe Audio"):
        files = {"file": (uploaded_file.name, uploaded_file, "audio/wav")}
        response = requests.post(f"{VOICE_AGENT_URL}/transcribe", files=files)
        if response.status_code == 200:
            text = response.json().get("text", "")
            st.text_area("Transcription:", value=text, height=150)
        else:
            st.error("Error transcribing audio.")
 
